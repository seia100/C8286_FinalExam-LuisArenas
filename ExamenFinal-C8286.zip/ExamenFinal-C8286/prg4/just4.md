# Pregunta 4 (5 puntos): Implementar un sistema distribuido en Python que simule las tres propiedades del Teorema CAP: consistencia, disponibilidad y tolerancia a particiones. El sistema debe demostrar cómo se comporta bajo diferentes configuraciones.

## En el código debes incluir:
• La simulación de latencia de red en la comunicación entre nodos.
• Un algoritmo de consenso sencillo como Raft o Paxos para gestionar la consistencia.
• Fallos aleatorios en los nodos para simular fallos de red o nodos caídos.
• Registros de operaciones y versiones de datos para gestionar la consistencia eventual.
• Diferentes configuraciones de particiones y curaciones en la red.

## Explicacion del codigo


**Configuración del Registro de Logs:**    
    Configura el registro de logs para mostrar información de depuración y errores.

**Clase Node:**
    Cada nodo tiene un almacén de datos (data_store), un registro de operaciones (log), y una configuración de términos y votos para el algoritmo de consenso.

**Métodos de la Clase Node:**
    send_message: Simula la latencia de red y la posibilidad de fallo en el envío de mensajes.
    receive_message: Recibe y maneja mensajes.
    handle_message: Maneja mensajes según su tipo (request_vote o append_entries).
    handle_request_vote: Maneja las solicitudes de voto para el algoritmo de consenso.
    handle_append_entries: Maneja las entradas adicionales para mantener la consistencia.
    request_vote: Solicita votos de otros nodos para convertirse en líder.
    append_entries: Añade entradas al registro y actualiza otros nodos.
    simulate_network_partition: Simula una partición de red eliminando nodos de la red.
    heal_network_partition: Cura una partición de red reintegrando nodos a la red.

**Función simulate_distributed_system:**
    Crea y configura los nodos.
    Simula operaciones y una partición de red, y luego cura la partición.
    Muestra el estado final de los nodos.


## Solution
Para implementar un sistema CAP (consistencia, disponibilidad y Tolerancia a particiones) es necesario los siguientes pasos:

- **Simulación de latencia de red:** Añadiremos retardos en la comunicación entre nodos.
- **Algoritmo de consenso:** Usaremos una versión simplificada del algoritmo Raft.
- **Fallos aleatorios:** Simularemos fallos en los nodos.
- **Registros de operaciones y versiones de datos:** Mantendremos un registro de operaciones para gestionar la consistencia eventual.
- **Configuraciones de particiones y curaciones en la red:** Configuraremos diferentes escenarios de particiones de red.

## Interpretacion
### output
![CAP-simulation](image.png)

el output, representado en la imagen, muestra varios mensajes de pérdida de mensajes entre nodos debido a la simulación de fallos de red. Aquí está el estado final de los almacenes de datos en los nodos:

    Nodos 0, 1, y 2: {'x': 1}
    Nodos 3, 4, 5, 7, y 8: {'x': 1, 'y': 2}
    Nodos 6: {}

**Análisis Técnico**

    Simulación de Latencia de Red y Fallos:
        La latencia de red se simula con asyncio.sleep y la pérdida de mensajes con una probabilidad del 10%.
        Los mensajes perdidos entre nodos indican que algunos eventos de consenso y replicación no llegaron a todos los nodos.

    Consistencia:
        La inconsistencia se observa claramente. Algunos nodos tienen solo {'x': 1} mientras que otros tienen {'x': 1, 'y': 2}.
        La inconsistencia puede deberse a fallos de red durante la replicación de la segunda operación {'y': 2}.

    Disponibilidad:
        A pesar de las pérdidas de mensajes, los nodos que pudieron procesar las solicitudes de escritura actualizaron sus almacenes de datos.
        El sistema sigue disponible ya que responde a las solicitudes de escritura incluso con fallos de red.

    Tolerancia a Particiones:
        La partición de red se simula eliminando temporalmente algunos nodos de la red y luego curando la partición.
        Los nodos 1 y 2 no tienen el valor {'y': 2}, lo que sugiere que estaban en una partición durante la segunda operación y no se reconciliaron correctamente después de curar la partición.


En suma, el sistema se comporta como se espera bajo el Teorema CAP, sacrificando la consistencia por la disponibilidad y tolerancia a particiones. Las inconsistencias observadas subrayan la importancia de elegir correctamente el diseño de un sistema distribuido según las necesidades específicas de la aplicación y el entorno operativo.