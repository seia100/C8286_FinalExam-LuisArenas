import asyncio
import random
import time
import logging
from collections import defaultdict

# Configuración del registro de logs
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class Node:
    def __init__(self, node_id, nodes):
        self.node_id = node_id
        self.nodes = nodes  # Lista de nodos en la red
        self.data_store = {}  # Almacén de datos
        self.log = []  # Registro de operaciones
        self.current_term = 0  # Término actual en el algoritmo de consenso
        self.voted_for = None  # Nodo al que este nodo ha votado
        self.commit_index = 0  # Índice de confirmación de operaciones
        self.lock = asyncio.Lock()  # Para asegurar operaciones seguras en concurrencia

    async def send_message(self, target_node, message):
        # Simulación de latencia de red
        await asyncio.sleep(random.uniform(0.1, 1.0))
        if random.random() < 0.1:  # Simular fallo en el envío del mensaje
            logging.info(f'Message from Node {self.node_id} to Node {target_node.node_id} lost.')
            return
        await target_node.receive_message(message)

    async def receive_message(self, message):
        await self.handle_message(message)

    async def handle_message(self, message):
        # Manejo de mensajes según el tipo
        if message['type'] == 'request_vote':
            await self.handle_request_vote(message)
        elif message['type'] == 'append_entries':
            await self.handle_append_entries(message)

    async def handle_request_vote(self, message):
        async with self.lock:
            if message['term'] > self.current_term:
                self.current_term = message['term']
                self.voted_for = None
            if self.voted_for is None and message['term'] == self.current_term:
                self.voted_for = message['candidate_id']
                response = {
                    'type': 'vote_response',
                    'term': self.current_term,
                    'vote_granted': True,
                    'from_node': self.node_id
                }
                await self.send_message(self.nodes[message['candidate_id']], response)

    async def handle_append_entries(self, message):
        async with self.lock:
            if message['term'] >= self.current_term:
                self.current_term = message['term']
                self.log.extend(message['entries'])
                self.commit_index = message['commit_index']
                for entry in message['entries']:
                    self.data_store[entry['key']] = entry['value']
                response = {
                    'type': 'append_response',
                    'term': self.current_term,
                    'success': True,
                    'from_node': self.node_id
                }
                await self.send_message(self.nodes[message['leader_id']], response)

    async def request_vote(self):
        async with self.lock:
            self.current_term += 1
            self.voted_for = self.node_id
            votes = 1
            for node in self.nodes.values():
                if node.node_id != self.node_id:
                    message = {
                        'type': 'request_vote',
                        'term': self.current_term,
                        'candidate_id': self.node_id
                    }
                    await self.send_message(node, message)

    async def append_entries(self, entries):
        async with self.lock:
            self.log.extend(entries)
            self.commit_index = len(self.log)
            for node in self.nodes.values():
                if node.node_id != self.node_id:
                    message = {
                        'type': 'append_entries',
                        'term': self.current_term,
                        'leader_id': self.node_id,
                        'entries': entries,
                        'commit_index': self.commit_index
                    }
                    await self.send_message(node, message)

    async def simulate_network_partition(self, partitioned_nodes):
        # Simulación de partición de red
        for node in partitioned_nodes:
            self.nodes.pop(node.node_id, None)

    async def heal_network_partition(self, healed_nodes):
        # Curación de partición de red
        for node in healed_nodes:
            self.nodes[node.node_id] = node

async def simulate_distributed_system():
    # Creación de nodos
    nodes = {i: Node(i, {}) for i in range(10)}
    for node in nodes.values():
        node.nodes = nodes

    # Simulación de operaciones en el sistema distribuido
    leader_node = nodes[0]
    await leader_node.request_vote()
    await leader_node.append_entries([{'key': 'x', 'value': 1}])

    # Simulación de una partición de red
    partitioned_nodes = [nodes[1], nodes[2]]
    await leader_node.simulate_network_partition(partitioned_nodes)
    await asyncio.sleep(2)
    await leader_node.append_entries([{'key': 'y', 'value': 2}])

    # Curación de la partición de red
    await leader_node.heal_network_partition(partitioned_nodes)

    # Visualización del estado final de los nodos
    for node in nodes.values():
        print(f'Node {node.node_id} data store: {node.data_store}')

if __name__ == '__main__':
    asyncio.run(simulate_distributed_system())
